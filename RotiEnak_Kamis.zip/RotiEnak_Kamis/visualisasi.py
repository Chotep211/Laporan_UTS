# =============================================================================
# KODE TAMBAHAN UNTUK VISUALISASI HASIL
# =============================================================================

import matplotlib.pyplot as plt
import numpy as np

def visualisasi_hasil():
    """Fungsi untuk membuat visualisasi hasil optimasi"""
    
    # Data dari hasil optimasi
    pabrik = ['P1', 'P2']
    utilisasi = [200, 150]  # Dari hasil perhitungan
    kapasitas = [200, 150]
    
    # Buat visualisasi
    fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 10))
    
    # 1. Chart Utilisasi Pabrik
    x = np.arange(len(pabrik))
    width = 0.35
    
    ax1.bar(x, kapasitas, width, label='Kapasitas', alpha=0.6)
    ax1.bar(x, utilisasi, width, label='Terpakai')
    ax1.set_xlabel('Pabrik')
    ax1.set_ylabel('Jumlah Unit')
    ax1.set_title('UTILISASI KAPASITAS PABRIK')
    ax1.set_xticks(x)
    ax1.set_xticklabels(pabrik)
    ax1.legend()
    
    # 2. Chart Distribusi per Toko
    toko = ['T1', 'T2', 'T3']
    distribusi = [210, 240, 180]  # Total pengiriman per toko
    
    ax2.pie(distribusi, labels=toko, autopct='%1.1f%%', startangle=90)
    ax2.set_title('DISTRIBUSI PER TOKO')
    
    # 3. Chart Biaya per Rute
    rute = ['P1→T3', 'P2→T2', 'P2→T1', 'P1→T1', 'P1→T2']
    biaya_rute = [1060000, 1130000, 1110000, 400000, 560000]
    
    ax3.barh(rute, biaya_rute)
    ax3.set_xlabel('Biaya (Rupiah)')
    ax3.set_title('BIAYA PER RUTE')
    
    # 4. Chart Jenis Roti
    jenis = ['Roti A', 'Roti B', 'Roti C']
    produksi = [240, 180, 210]
    
    ax4.bar(jenis, produksi, color=['skyblue', 'lightcoral', 'lightgreen'])
    ax4.set_ylabel('Jumlah Unit')
    ax4.set_title('PRODUKSI PER JENIS ROTI')
    
    plt.tight_layout()
    plt.savefig('optimasi_rotienak.png', dpi=300, bbox_inches='tight')
    plt.show()

# Jalankan visualisasi (opsional)
# visualisasi_hasil()