# =============================================================================
# OPTIMASI DISTRIBUSI PT ROTIENAK MENGGUNAKAN LINEAR PROGRAMMING
# =============================================================================

import pulp as plp
import pandas as pd

def main():
    print("=" * 70)
    print("OPTIMASI DISTRIBUSI PT ROTIENAK")
    print("Menggunakan Linear Programming dengan PuLP")
    print("=" * 70)
    
    # =========================================================================
    # 1. INISIALISASI MODEL
    # =========================================================================
    
    # Membuat model minimisasi
    model = plp.LpProblem("Optimasi_Distribusi_RotiEnak", plp.LpMinimize)
    
    print("1. Model optimasi berhasil diinisialisasi")
    
    # =========================================================================
    # 2. DATA PERUSAHAAN
    # =========================================================================
    
    # Set data
    pabrik = ['P1', 'P2']
    toko = ['T1', 'T2', 'T3']
    jenis_roti = ['A', 'B', 'C']
    
    # Kapasitas pabrik (unit/hari)
    kapasitas = {
        'P1': 200,
        'P2': 150
    }
    
    # Permintaan toko per jenis roti
    permintaan = {
        ('T1', 'A'): 80, ('T1', 'B'): 60, ('T1', 'C'): 70,
        ('T2', 'A'): 90, ('T2', 'B'): 70, ('T2', 'C'): 80,
        ('T3', 'A'): 70, ('T3', 'B'): 50, ('T3', 'C'): 60
    }
    
    # Biaya pengiriman per unit (dalam Rupiah)
    biaya = {
        ('P1', 'T1', 'A'): 5000, ('P1', 'T1', 'B'): 7000, ('P1', 'T1', 'C'): 6000,
        ('P1', 'T2', 'A'): 6000, ('P1', 'T2', 'B'): 8000, ('P1', 'T2', 'C'): 7000,
        ('P1', 'T3', 'A'): 4000, ('P1', 'T3', 'B'): 6000, ('P1', 'T3', 'C'): 5000,
        ('P2', 'T1', 'A'): 7000, ('P2', 'T1', 'B'): 9000, ('P2', 'T1', 'C'): 8000,
        ('P2', 'T2', 'A'): 5000, ('P2', 'T2', 'B'): 7000, ('P2', 'T2', 'C'): 6000,
        ('P2', 'T3', 'A'): 6000, ('P2', 'T3', 'B'): 8000, ('P2', 'T3', 'C'): 7000
    }
    
    print("2. Data perusahaan berhasil dimuat")
    print(f"   - Jumlah pabrik: {len(pabrik)}")
    print(f"   - Jumlah toko: {len(toko)}")
    print(f"   - Jenis roti: {len(jenis_roti)}")
    print(f"   - Total kapasitas: {sum(kapasitas.values())} unit")
    print(f"   - Total permintaan: {sum([sum([permintaan[(t,k)] for k in ['A','B','C']]) for t in toko])} unit")
    
    # =========================================================================
    # 3. VARIABEL KEPUTUSAN
    # =========================================================================
    
    # Membuat variabel keputusan x[i,j,k]
    x = plp.LpVariable.dicts("Pengiriman", 
                            [(i, j, k) for i in pabrik 
                                       for j in toko 
                                       for k in jenis_roti],
                            lowBound=0,
                            cat='Integer')
    
    print("3. Variabel keputusan berhasil dibuat")
    print(f"   - Jumlah variabel: {len(x)}")
    
    # =========================================================================
    # 4. FUNGSI TUJUAN - MINIMASI BIAYA
    # =========================================================================
    
    # Fungsi tujuan: Minimalkan total biaya pengiriman
    model += plp.lpSum([biaya[i, j, k] * x[i, j, k] 
                       for i in pabrik 
                       for j in toko 
                       for k in jenis_roti])
    
    print("4. Fungsi tujuan berhasil ditetapkan: Minimasi Biaya Total")
    
    # =========================================================================
    # 5. KENDALA KAPASITAS PABRIK
    # =========================================================================
    
    # Kendala kapasitas untuk setiap pabrik
    for i in pabrik:
        model += plp.lpSum([x[i, j, k] for j in toko for k in jenis_roti]) <= kapasitas[i]
    
    print("5. Kendala kapasitas pabrik berhasil ditambahkan")
    
    # =========================================================================
    # 6. KENDALA PERMINTAAN TOKO
    # =========================================================================
    
    # Kendala permintaan untuk setiap toko dan setiap jenis roti
    for j in toko:
        for k in jenis_roti:
            model += plp.lpSum([x[i, j, k] for i in pabrik]) == permintaan[(j, k)]
    
    print("6. Kendala permintaan toko berhasil ditambahkan")
    
    # =========================================================================
    # 7. SOLUSI MODEL
    # =========================================================================
    
    print("\n" + "=" * 70)
    print("MEMECAHKAN MODEL OPTIMASI...")
    print("=" * 70)
    
    # Memecahkan model
    model.solve()
    
    # =========================================================================
    # 8. MENAMPILKAN HASIL
    # =========================================================================
    
    print("\n" + "=" * 70)
    print("HASIL OPTIMASI")
    print("=" * 70)
    
    # Status solusi
    print(f"Status Solusi: {plp.LpStatus[model.status]}")
    print(f"Total Biaya Optimal: Rp {plp.value(model.objective):,}")
    
    # =========================================================================
    # 9. TABEL DISTRIBUSI OPTIMAL
    # =========================================================================
    
    print("\n" + "=" * 70)
    print("RENCANA DISTRIBUSI OPTIMAL")
    print("=" * 70)
    
    # Membuat dataframe untuk hasil
    hasil_data = []
    
    for i in pabrik:
        for j in toko:
            for k in jenis_roti:
                quantity = x[i, j, k].varValue
                if quantity > 0:
                    cost = biaya[i, j, k] * quantity
                    hasil_data.append({
                        'Dari': i,
                        'Ke': j,
                        'Jenis Roti': k,
                        'Jumlah': quantity,
                        'Biaya per Unit': f"Rp {biaya[i, j, k]:,}",
                        'Total Biaya': f"Rp {cost:,}"
                    })
    
    # Menampilkan tabel distribusi
    df_hasil = pd.DataFrame(hasil_data)
    if not df_hasil.empty:
        print(df_hasil.to_string(index=False))
    else:
        print("Tidak ada solusi yang ditemukan")
    
    # =========================================================================
    # 10. ANALISIS UTILISASI
    # =========================================================================
    
    print("\n" + "=" * 70)
    print("ANALISIS UTILISASI KAPASITAS")
    print("=" * 70)
    
    for i in pabrik:
        total_kirim = sum([x[i, j, k].varValue for j in toko for k in jenis_roti])
        utilisasi = (total_kirim / kapasitas[i]) * 100
        print(f"{i}: {total_kirim}/{kapasitas[i]} unit ({utilisasi:.1f}%)")
    
    # =========================================================================
    # 11. PEMENUHAN PERMINTAAN
    # =========================================================================
    
    print("\n" + "=" * 70)
    print("PEMENUHAN PERMINTAAN TOKO")
    print("=" * 70)
    
    for j in toko:
        print(f"\n{j}:")
        for k in jenis_roti:
            terkirim = sum([x[i, j, k].varValue for i in pabrik])
            diminta = permintaan[(j, k)]
            status = "✅ TERPENUHI" if terkirim == diminta else "❌ KURANG"
            print(f"  {k}: {terkirim}/{diminta} unit {status}")
    
    # =========================================================================
    # 12. RINGKASAN BIAYA PER RUTE
    # =========================================================================
    
    print("\n" + "=" * 70)
    print("RINGKASAN BIAYA PER RUTE")
    print("=" * 70)
    
    rute_costs = {}
    for i in pabrik:
        for j in toko:
            total_rute = sum([biaya[i, j, k] * x[i, j, k].varValue for k in jenis_roti])
            if total_rute > 0:
                rute_costs[f"{i}→{j}"] = total_rute
    
    # Urutkan dari biaya tertinggi ke terendah
    for rute, biaya_rute in sorted(rute_costs.items(), key=lambda x: x[1], reverse=True):
        print(f"{rute}: Rp {biaya_rute:,}")
    
    # =========================================================================
    # 13. SIMULASI PERUBAHAN BIAYA
    # =========================================================================
    
    print("\n" + "=" * 70)
    print("ANALISIS SENSITIVITAS")
    print("=" * 70)
    
    # Simulasi kenaikan biaya P1→T3 (rute terbaik)
    biaya_asli = biaya[('P1', 'T3', 'A')]
    biaya_baru = 7000  # Naik dari 4000 menjadi 7000
    
    print(f"\nSimulasi: Biaya P1→T3 (Roti A) naik dari Rp {biaya_asli:,} menjadi Rp {biaya_baru:,}")
    
    # Hitung dampak dengan asumsi alokasi tetap
    alokasi_t3a = x[('P1', 'T3', 'A')].varValue
    dampak_biaya = (biaya_baru - biaya_asli) * alokasi_t3a
    print(f"Dampak pada biaya total: Rp {dampak_biaya:,}")
    print(f"Perkiraan biaya total baru: Rp {plp.value(model.objective) + dampak_biaya:,}")
    
    # =========================================================================
    # 14. REKOMENDASI STRATEGIS
    # =========================================================================
    
    print("\n" + "=" * 70)
    print("REKOMENDASI STRATEGIS")
    print("=" * 70)
    
    print("1. PRIORITAS RUTE:")
    print("   ✅ P1→T3: Biaya terendah, optimalkan kapasitas")
    print("   ✅ P2→T2: Efisien untuk P2, pertahankan")
    print("   ❌ P2→T3: Hindari - biaya tidak kompetitif")
    
    print("\n2. MANAJEMEN KAPASITAS:")
    print("   ✅ Kedua pabrik beroperasi 100%")
    print("   ⚠️  Pertimbangkan ekspansi untuk memenuhi excess demand")
    
    print("\n3. PENGENDALIAN BIAYA:")
    print(f"   ✅ Biaya optimal: Rp {plp.value(model.objective):,}")
    print("   📊 Monitor biaya rute P1→T3 (paling sensitif)")

if __name__ == "__main__":
    main()