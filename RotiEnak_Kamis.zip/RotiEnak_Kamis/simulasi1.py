def simulasi_kenaikan_biaya_p1_t3():
    """Simulasi kenaikan biaya pada rute P1→T3 (rute terbaik)"""
    print("=" * 70)
    print("SIMULASI 1: KENAIKAN BIAYA P1→T3")
    print("=" * 70)
    
    # Data awal
    biaya_asli = {
        ('P1', 'T3', 'A'): 4000, ('P1', 'T3', 'B'): 6000, ('P1', 'T3', 'C'): 5000
    }
    
    skenario_kenaikan = [
        {"nama": "Skenario 1", "kenaikan": 25, 'A': 5000, 'B': 7500, 'C': 6250},
        {"nama": "Skenario 2", "kenaikan": 50, 'A': 6000, 'B': 9000, 'C': 7500},
        {"nama": "Skenario 3", "kenaikan": 75, 'A': 7000, 'B': 10500, 'C': 8750}
    ]
    
    print("Biaya Awal P1→T3:")
    print(f"  Roti A: Rp {biaya_asli[('P1','T3','A')]:,}")
    print(f"  Roti B: Rp {biaya_asli[('P1','T3','B')]:,}") 
    print(f"  Roti C: Rp {biaya_asli[('P1','T3','C')]:,}")
    print(f"  Total Alokasi P1→T3: 180 unit")
    print(f"  Biaya Awal P1→T3: Rp 1,060,000")
    
    print("\nHasil Simulasi Kenaikan Biaya:")
    for skenario in skenario_kenaikan:
        biaya_baru = (70 * skenario['A'] + 50 * skenario['B'] + 60 * skenario['C'])
        kenaikan_biaya = biaya_baru - 1060000
        biaya_total_baru = 4260000 + kenaikan_biaya
        
        print(f"\n{skenario['nama']} (+{skenario['kenaikan']}%):")
        print(f"  Biaya P1→T3 Baru: Rp {biaya_baru:,}")
        print(f"  Kenaikan Biaya: Rp {kenaikan_biaya:,}")
        print(f"  Total Biaya Baru: Rp {biaya_total_baru:,}")
        print(f"  % Kenaikan Total: {(kenaikan_biaya/4260000)*100:.1f}%")

simulasi_kenaikan_biaya_p1_t3()