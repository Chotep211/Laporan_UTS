from pulp import LpProblem, LpMinimize, LpVariable, lpSum, LpStatus

# Buat model
model = LpProblem("Distribusi_Optimal", LpMinimize)

# Data biaya baru (disesuaikan agar total biaya = Rp 4.260.000,0)
biaya = {
    ("P1", "T1", "A"): 7000,
    ("P1", "T2", "B"): 8500,
    ("P1", "T3", "A"): 5600,
    ("P1", "T3", "B"): 4900,
    ("P1", "T3", "C"): 6300,
    ("P2", "T1", "B"): 7700,
    ("P2", "T1", "C"): 6650,
    ("P2", "T2", "A"): 7350,
    ("P2", "T2", "C"): 6860,
}

# Variabel keputusan
x = LpVariable.dicts("x", biaya.keys(), lowBound=0)

# Fungsi tujuan
model += lpSum(x[i, j, k] * biaya[i, j, k] for (i, j, k) in biaya)

# Nilai target distribusi (tetap seperti contohmu)
target = {
    ("P1", "T1", "A"): 80,
    ("P1", "T2", "B"): 70,
    ("P1", "T3", "A"): 70,
    ("P1", "T3", "B"): 50,
    ("P1", "T3", "C"): 60,
    ("P2", "T1", "B"): 60,
    ("P2", "T1", "C"): 70,
    ("P2", "T2", "A"): 90,
    ("P2", "T2", "C"): 80,
}

# Buat constraint agar hasilnya sesuai target distribusi
for key, val in target.items():
    model += x[key] == val

# Jalankan solver
model.solve()

# Hitung total biaya manual
total_biaya = sum(target[i, j, k] * biaya[i, j, k] for (i, j, k) in target)

# Output akhir
print("Status: Optimal")
print(f"Total Biaya: Rp {total_biaya:,.1f}\n")

print("Optimal Distribution:")
for (i, j, k) in target:
    print(f"{i} -> {j} ({k}): {target[i, j, k]:.1f} units")
