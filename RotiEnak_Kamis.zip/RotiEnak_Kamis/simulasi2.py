def simulasi_ekspansi_kapasitas():
    """Simulasi penambahan kapasitas produksi"""
    print("\n" + "=" * 70)
    print("SIMULASI 2: EKSPANSI KAPASITAS PRODUKSI")
    print("=" * 70)
    
    skenario_ekspansi = [
        {"nama": "Tambah P1 50 unit", "p1_tambah": 50, "p2_tambah": 0},
        {"nama": "Tambah P2 50 unit", "p1_tambah": 0, "p2_tambah": 50},
        {"nama": "Tambah Kedua 25 unit", "p1_tambah": 25, "p2_tambah": 25},
        {"nama": "Ekspansi Besar", "p1_tambah": 100, "p2_tambah": 100}
    ]
    
    # Asumsi biaya marginal per unit
    biaya_marginal_p1 = 4500  # Rata-rata biaya P1
    biaya_marginal_p2 = 6500  # Rata-rata biaya P2
    
    print("Kapasitas Awal: P1=200, P2=150 (Total: 350 unit)")
    print("Permintaan Total: 630 unit")
    print("Supply-Demand Gap: 280 unit\n")
    
    for skenario in skenario_ekspansi:
        kapasitas_tambah = skenario['p1_tambah'] + skenario['p2_tambah']
        pemenuhan_tambah = min(kapasitas_tambah, 280)  # Maksimal penuhi gap
        
        biaya_tambahan = (skenario['p1_tambah'] * biaya_marginal_p1 + 
                         skenario['p2_tambah'] * biaya_marginal_p2)
        
        pendapatan_tambahan = pemenuhan_tambah * 15000  # Asumsi margin
        
        print(f"{skenario['nama']}:")
        print(f"  Kapasitas Tambah: {kapasitas_tambah} unit")
        print(f"  Pemenuhan Demand Tambah: {pemenuhan_tambah} unit")
        print(f"  Biaya Produksi Tambah: Rp {biaya_tambahan:,}")
        print(f"  Pendapatan Tambah: Rp {pendapatan_tambahan:,}")
        print(f"  Profit Tambah: Rp {pendapatan_tambahan - biaya_tambahan:,}")

simulasi_ekspansi_kapasitas()